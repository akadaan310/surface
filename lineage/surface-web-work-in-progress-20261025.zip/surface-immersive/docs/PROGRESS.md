# Surface rebuild ledger

2026-10-25 — Fresh rebuild authorized by user after inaccessible prior session. Original files are preserved in the parent workspace. This repository is a new application, not evidence of recovery of lost code.

Ruling: use a buildless local browser runtime and versioned hosted source — minimizes dependencies on session/network state. Persist development checkpoints and user simulation states separately. No global freeze guarantee is claimed.

Plan tasks 1–3 assigned to independent components; task 4 is root integration. Only root manages Site identity, source publication and release.
