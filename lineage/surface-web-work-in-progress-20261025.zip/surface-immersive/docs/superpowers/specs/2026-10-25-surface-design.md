# Surface: physical ink

## Authority and intent
The user explicitly authorizes a fresh Surface after the old session lost its connection, delegates implementation choices, and requires a fully immersive fullscreen surface with no visible interface. This instruction replaces the attached resume prompt's preserve-existing-site requirement. Original scientific archives remain immutable evidence; this build must not claim to recover the inaccessible session or to have completed its old gates.

## Experience
A viewport-filling, dark optical field, already alive on entry. Drawing deposits energy and material; response propagates through the field. The only visible content is ink. No header, menus, controls, text, or on-screen status. Pointer/touch input, discreet keyboard shortcuts and multi-touch gestures control the surface. Instructions and scientific provenance live in documentation and exported records. Fullscreen uses the browser's user-gesture permission; ordinary mode still fills the viewport. Reduced-motion preference, keyboard input and screen-reader description are supported without visible chrome.

## Approach (builder decision)
Use buildless ES modules, a dedicated simulation worker, WebGL rendering with Canvas fallback, and browser-local transactional checkpoints. This is a deterministic reduced physical model, with separately declared visual observation transforms. A bounded real astronomical catalogue is shipped with metadata; it must never be called a complete universe or billion-source implementation. A modular native scientific backend remains an extension, not a claimed browser capability.

Alternatives considered: a server-only simulation makes drawing depend on connection health; a heavy framework and WebGPU-only renderer add failure points without helping this canvas experience. The selected static application loads its complete runtime locally and keeps working after network loss once loaded.

## Model and evidence
Implement stable wave propagation, heat diffusion, analytic electrostatic/magnetic fields, simple coupled circuit/charging references, magnetic state readout and wavelength/color transforms. State units, numerical scales, approximation regimes and rendering losses. Separate actual catalogue coordinates from artistic seed fields. Preserve original archives and maintain a PHANTOM binary/provenance adapter; no unsupported equivalence to quantum hardware.

## Recovery
The main thread supervises a dedicated worker through epoch-fenced messages and bounded request deadlines. Checkpoints include complete simulation state, input log, schema/version, checksums and visible-mode state. Restore the newest valid committed checkpoint; do not trust corrupt or incomplete input. Retain a previous good checkpoint and make portable JSON export/import available without a persistent UI. Handle hidden tabs without mistaking suspension for failed computation. Stop automatic restart after a bounded failure count. A browser/system process failure is outside this in-page supervisor's control.

## Delivery
Publish a private Site with versioned source, preserve a downloadable source/recovery archive, include tests and exact completion boundaries, and return the real URL. Never make user-visible progress depend on a long-running ingestion job. Future continuation begins from the actual source repository and saved checkpoint, not this conversation alone.
