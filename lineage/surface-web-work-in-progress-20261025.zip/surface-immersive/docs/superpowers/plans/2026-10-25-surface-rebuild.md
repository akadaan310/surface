# Surface Rebuild Implementation Plan

> **For agentic workers:** Execute the bounded component tasks below and retain evidence. User has authorized direct implementation.

**Goal:** A working immersive, recoverable Surface built from the preserved PHANTOM lineage.

**Architecture:** Static ES modules with a worker for reduced physical models, a main-thread supervisor and persistent checkpoint store, and a full-viewport renderer. Exact data and display transforms stay separate.

**Tech Stack:** JavaScript modules, Web Workers, WebGL/Canvas, IndexedDB, Node test runner, Sites private hosting.

**Spec:** `docs/superpowers/specs/2026-10-25-surface-design.md`

## Global constraints
- No visible interface. Source-controlled documentation, export and keyboard controls are allowed.
- Do not modify the supplied archives or certify historical scientific tests as freshly passed.
- Local browser interaction must not depend on continuous network connectivity.
- Bound computation, restarts, particle counts, memory, catalogue and imports.
- No forced scientific meaning for artistic rendering choices.

## Review focus
- Corrupt, oversized or sparse numeric imports cannot enter solvers.
- A late response from an old worker cannot replace current state.
- Hidden-tab time suspension cannot trigger endless restart or explosive time catchup.
- Input, resize, keyboard and touch remain usable without visible controls.
- Missing catalogue distances or non-physical display transforms remain explicit.

## Task 1 — Physical model (parallel owner)
- [ ] Create `dist/js/physics.mjs`, meaningful analytical/numerical tests and model notes.
- [ ] Interface: `PhysicsEngine({width,height,seed})`, `inject({x,y,dx,dy,strength,radius,mode})`, `step(dt)`, `frame()`, `serialize()`, `restore(state)`.
- [ ] Frame fields are Float32Arrays: density, heat, pressure, potential, bx, by, ex, ey; dimensions and simulation time included.
- [ ] Reject nonfinite/unstable states; verify wave speed, heat behavior, magnetic symmetry, coupling/charge and serialization.

## Task 2 — Worker supervision and checkpoints (parallel owner)
- [ ] Create worker adapter, epoch-fenced bridge, IndexedDB store and tests.
- [ ] Interface: `SimulationBridge({onFrame,onStatus,onCheckpoint})`; `start(snapshot?)`, `inject(event)`, `pause(bool)`, `checkpoint()`, `reset()`, `dispose()`.
- [ ] Main-thread watchdog controls a separate worker; restarts bounded, complete checkpoints persisted and validated.
- [ ] Export/import and corrupt/late/timeout cases exercised.

## Task 3 — Catalogue and PHANTOM bridge (parallel owner)
- [ ] Create bounded sourced star data, coordinate functions and provenance adapter.
- [ ] Preserve source identifiers, unit/epoch/missing-data metadata, originals and exact byte digests.
- [ ] Read upstream implementation and document what is reused versus newly implemented.
- [ ] Verify coordinate basis, binary admission/roundtrip and data count.

## Task 4 — Immersive experience (root)
- [ ] Create renderer, full-viewport page, input/audio controller and integration.
- [ ] Direct ink painting and physical modalities; sky projection from real catalogue.
- [ ] No visible chrome, fullscreen gesture, pause, capture, portable state export/import and mobile gestures.
- [ ] Verify browser appearance/interaction and fallback, test integration boundaries.

## Task 5 — Release and recovery (root)
- [ ] Run combined tests and browser QA; obtain independent review and fix consequential findings.
- [ ] Preserve science sources, inherited gate statuses, actual test receipts and resume instructions.
- [ ] Push source, package exact revision, deploy private Site and report returned URL.
- [ ] Preserve portable source/recovery artifact and verify its archive.
