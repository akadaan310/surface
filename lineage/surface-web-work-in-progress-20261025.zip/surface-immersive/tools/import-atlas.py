#!/usr/bin/env python3
"""Bounded Gaia DR3 import. Default: transform the preserved local CSV only.

Optional --fetch makes one public ESA TAP request with a 50-second socket timeout,
at most 5 MB, and no background retries. Runtime never needs the archive service.
"""
import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist' / 'data'
RAW = OUT / 'gaia-dr3-bright-source.csv'
QUERY = ('SELECT TOP 10000 source_id,ref_epoch,ra,dec,parallax,parallax_error,'
         'phot_g_mean_mag,bp_rp FROM gaiadr3.gaia_source '
         'WHERE phot_g_mean_mag < 7.5 ORDER BY phot_g_mean_mag ASC')
ENDPOINT = 'https://gea.esac.esa.int/tap-server/tap/sync'

def number(value):
    if value == '':
        return None
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('Nonfinite catalogue value')
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fetch', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.fetch:
        url = ENDPOINT + '?' + urllib.parse.urlencode(
            {'REQUEST':'doQuery', 'LANG':'ADQL', 'FORMAT':'csv', 'QUERY':QUERY})
        with urllib.request.urlopen(url, timeout=50) as response:
            payload = response.read(5_000_001)
        if len(payload) > 5_000_000 or not payload.startswith(b'source_id,'):
            raise ValueError('Response exceeds bounds or is not expected CSV')
        RAW.write_bytes(payload)
    payload = RAW.read_bytes()
    if len(payload) > 5_000_000:
        raise ValueError('Raw data exceeds 5 MB bound')
    stars = []
    seen = set()
    for row in csv.DictReader(io.StringIO(payload.decode('utf-8'))):
        sid = row['source_id']
        if not sid.isdecimal() or sid in seen:
            raise ValueError('Missing/duplicate/nondecimal source ID')
        seen.add(sid)
        if number(row['ref_epoch']) != 2016:
            raise ValueError('Unexpected reference epoch')
        star = dict(id=sid, ra=number(row['ra']), dec=number(row['dec']),
                    mag=number(row['phot_g_mean_mag']), colorIndex=number(row['bp_rp']),
                    parallaxMas=number(row['parallax']),
                    parallaxErrorMas=number(row['parallax_error']), distancePc=None)
        if not 0 <= star['ra'] < 360 or not -90 <= star['dec'] <= 90 or star['mag'] >= 7.5:
            raise ValueError('Source lies outside declared selection/coordinate bounds')
        stars.append(star)
    if len(stars) != 10_000:
        raise ValueError(f'Expected pinned 10000 sources, found {len(stars)}')
    metadata = {
        'schema':'SURFACE-ATLAS/1', 'name':'Gaia DR3 bounded bright-source catalogue',
        'count':len(stars), 'frame':'ICRS', 'epochJulianYear':2016.0,
        'units':{'ra':'degree','dec':'degree','mag':'Gaia G magnitude',
                 'colorIndex':'Gaia BP−RP magnitude','parallaxMas':'milliarcsecond',
                 'parallaxErrorMas':'milliarcsecond','distancePc':'parsec'},
        'selection':QUERY, 'retrievedUTC':'2026-10-25',
        'source':{'endpoint':ENDPOINT,'table':'gaiadr3.gaia_source',
                  'rawFile':RAW.name, 'sha256':hashlib.sha256(payload).hexdigest(),
                  'bytes':len(payload)},
        'distancePolicy':'All distancePc values are null. No inverse-parallax distance is inferred; raw parallax and uncertainty are retained when available.',
        'displayPolicy':'Directions projected onto a unit sphere. Pixel positions, halo sizes and display colors are observation transforms, not measured spatial extent or calibrated spectra.',
        'limitations':['10000 sources only; no completeness claim, including bright-star incompleteness in Gaia.',
                       'Coordinates remain at J2016.0; proper motion, observer location, extinction and aberration are not applied.',
                       'BP−RP is a color index, not temperature; missing values remain null.'],
        'license':{'name':'CC BY-NC 3.0 IGO',
                   'url':'https://www.cosmos.esa.int/web/gaia-users/license',
                   'legalCode':'https://creativecommons.org/licenses/by-nc/3.0/igo/'},
        'attribution':'ESA/Gaia/DPAC. This work uses Gaia mission data processed by the Gaia Data Processing and Analysis Consortium (DPAC); funding is provided by national institutions participating in the Gaia Multilateral Agreement.',
        'references':[
            'https://www.cosmos.esa.int/web/gaia/dr3',
            'https://gea.esac.esa.int/archive/documentation/GDR3/Gaia_archive/chap_datamodel/sec_dm_main_source_catalogue/ssec_dm_gaia_source.html',
            'https://www.cosmos.esa.int/web/gaia-users/archive/programmatic-access',
            'https://www.cosmos.esa.int/web/gaia-users/credits',
            'https://doi.org/10.1051/0004-6361/202243940']
    }
    dest = OUT / 'gaia-dr3-bright.json'
    dest.write_text(json.dumps({'meta':metadata,'stars':stars},ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
    print(json.dumps({'count':len(stars),'rawBytes':len(payload),'rawSha256':metadata['source']['sha256'],
                      'jsonBytes':dest.stat().st_size,'magnitudeRange':[stars[0]['mag'],stars[-1]['mag']]}))

if __name__ == '__main__':
    main()
