import test from 'node:test';
import assert from 'node:assert/strict';
import { PhysicsEngine, ENGINE_VERSION, fieldAt, updateMagneticMemory } from '../dist/js/physics.mjs';

function blank(width = 65, height = 33) {
  const engine = new PhysicsEngine({width, height, seed: 123});
  const state = engine.serialize();
  for (const values of Object.values(state.fields)) values.fill(0);
  state.sources = [];
  Object.assign(state.circuit, {i1:0,i2:0,q1:0,q2:0,drive:0,harvestedEnergy:0,dissipatedEnergy:0});
  state.memory.appliedField = 0;
  engine.restore(state);
  return engine;
}
const maximum = array => array.reduce((a,b)=>Math.max(a,Math.abs(b)),0);

test('seeded field is reproducible and has distributed positive and negative lobes', () => {
  const a = new PhysicsEngine({seed:55});
  const b = new PhysicsEngine({seed:55});
  assert.equal(ENGINE_VERSION,1);
  assert.deepEqual(a.serialize(), b.serialize());
  const f = a.frame();
  assert.ok(maximum(f.fields.density)>0.2);
  assert.ok(Math.min(...f.fields.potential)<-2);
  assert.ok(Math.max(...f.fields.potential)>2);
  assert.ok(f.sources.some(s=>s.x<.35) && f.sources.some(s=>s.x>.65));
});

test('scalar wave cosine mode follows independently calculated damped frequency', () => {
  const e=blank();
  const s=e.serialize();
  for(let y=0;y<33;y++) for(let x=0;x<65;x++) s.fields.pressure[y*65+x]=.4*Math.cos(Math.PI*x/64);
  e.restore(s);
  for(let i=0;i<120;i++) e.step(1/120);
  const gamma=.12, omega=.48*Math.PI/2, wd=Math.sqrt(omega*omega-gamma*gamma/4);
  const expected=.4*Math.exp(-gamma/2)*(Math.cos(wd)+gamma/(2*wd)*Math.sin(wd));
  assert.ok(Math.abs(e.frame().fields.pressure[16*65]-expected)<.004, `mode differs from analytical ${expected}`);
  assert.ok(Math.abs(e.frame().fields.pressure[16*65+32])<1e-5);
});

test('diffusion obeys the maximum principle and spreads positive heat', () => {
  const e=blank();const s=e.serialize();const center=16*65+32;
  s.fields.heat[center]=100;e.restore(s);
  e.step(.1);const heat=e.frame().fields.heat;
  assert.ok(heat[center]>0 && heat[center]<100);
  assert.ok(heat[center-1]>0 && heat[center+65]>0);
  assert.ok(heat.every(v=>v>=0 && v<=100));
});

test('positive charge creates an outward field and symmetric potential', () => {
  const source={x:0,y:0,q:1e-9,mx:0,my:0,core:.1};
  const right=fieldAt([source],1,0),left=fieldAt([source],-1,0);
  assert.ok(Math.abs(right.potential-8.9429464)<1e-5);
  assert.ok(Math.abs(right.ex-8.8544024)<1e-5);
  assert.equal(right.ey,0);assert.equal(right.ex,-left.ex);
  assert.equal(right.potential,left.potential);
});

test('regularized magnetic dipole has the correct axis and equator signs', () => {
  const source={x:0,y:0,q:0,mx:1,my:0,core:.1};
  const axis=fieldAt([source],1,0),equator=fieldAt([source],0,1),reverse=fieldAt([source],-1,0);
  assert.ok(axis.bx>0 && equator.bx<0);
  assert.equal(axis.by,0);assert.equal(equator.by,0);
  assert.equal(axis.bx,reverse.bx);
  assert.ok(Math.abs(axis.bx-1.97037067e-7)<1e-14);
  assert.ok(Number.isFinite(fieldAt([source],0,0).bx));
});

test('magnetic relays retain remanence and reverse only after coercive threshold', () => {
  const memory={relays:Array(15).fill(-1),magnetization:-1,appliedField:0};
  updateMagneticMemory(memory,2);assert.equal(memory.magnetization,1);
  updateMagneticMemory(memory,0);assert.equal(memory.magnetization,1);
  updateMagneticMemory(memory,-2);assert.equal(memory.magnetization,-1);
});

test('painting increases local tracer, thermal and wave energy and creates source pairs', () => {
  const e=blank();const n=e.frame().sources.length;
  e.inject({x:.5,y:.5,dx:.1,dy:.05,strength:1,radius:.05,mode:'coupled'});
  const f=e.frame();const center=16*65+32;
  assert.ok(f.fields.density[center]>.5);
  assert.ok(f.fields.heat[center]>1);
  assert.ok(Math.abs(f.fields.pressure[center])>.05);
  assert.equal(f.sources.length,n+2);
});

test('inductive reference transfers positive energy into a bounded battery reservoir', () => {
  const e=new PhysicsEngine({width:16,height:16});
  const before=e.frame().diagnostics.circuit;
  for(let i=0;i<360;i++)e.step(1/60);
  const c=e.frame().diagnostics.circuit;
  assert.ok(c.harvestedEnergy>0 && c.soc>before.soc && c.soc<=1);
  assert.ok(Math.abs(c.batteryEnergy-c.soc*432)<1e-8);
  assert.ok(c.storedEnergy>=0 && c.dissipatedEnergy>0);
});

test('serialized checkpoints survive JSON and resume bit-exact deterministic evolution', () => {
  const a=new PhysicsEngine({width:32,height:24,seed:91});
  a.inject({x:.42,y:.6,dx:.02,dy:-.01});for(let i=0;i<20;i++)a.step(1/60);
  const s=JSON.parse(JSON.stringify(a.serialize()));const b=new PhysicsEngine();b.restore(s);
  assert.deepEqual(b.serialize(),s);
  for(let i=0;i<30;i++){a.step(1/60);b.step(1/60);}
  assert.deepEqual(a.serialize(),b.serialize());
  assert.deepEqual(a.frame().fields,b.frame().fields);
});

test('malformed checkpoints fail atomically, including sparse arrays and invalid dimensions', () => {
  const e=new PhysicsEngine({width:16,height:16});const original=e.serialize();
  const corruptions=[s=>{s.fields.heat[0]=-1;},s=>{s.fields.pressure[2]=NaN;},s=>{delete s.fields.density[8];},s=>{s.sources[0].q=Infinity;},s=>{s.width=1;},s=>{s.memory.relays[0]=3;},s=>{s.circuit.soc=1.5;}];
  for(const mutate of corruptions){const s=structuredClone(original);mutate(s);assert.throws(()=>e.restore(s));assert.deepEqual(e.serialize(),original);}
});

test('invalid input cannot poison the live state', () => {
  const e=new PhysicsEngine({width:16,height:16});const original=e.serialize();
  for(const event of [{x:NaN,y:.5},{x:.5,y:Infinity},{x:.5,y:.5,dx:NaN},{x:.5,y:.5,strength:NaN}])assert.throws(()=>e.inject(event));
  for(const dt of [-1,NaN,Infinity])assert.throws(()=>e.step(dt));
  assert.deepEqual(e.serialize(),original);
  for(const dimensions of [{width:0},{height:512},{width:16.5}])assert.throws(()=>new PhysicsEngine(dimensions));
});

test('long steps are bounded, source count is capped, and all observable fields remain finite', () => {
  const e=new PhysicsEngine({width:32,height:24});
  for(let i=0;i<200;i++)e.inject({x:(i%20)/19,y:(i%13)/12,dx:.2,dy:-.2,strength:3});
  const before=e.frame().time;e.step(3600);const f=e.frame();
  assert.ok(f.time-before<=.1000001);
  assert.ok(f.diagnostics.discardedTime>3599);
  assert.ok(f.sources.length<=32);
  for(const field of Object.values(f.fields))assert.ok(field.every(Number.isFinite));
  for(let i=0;i<180;i++)e.step(1/30);
  for(const field of Object.values(e.frame().fields))assert.ok(field.every(Number.isFinite));
});
