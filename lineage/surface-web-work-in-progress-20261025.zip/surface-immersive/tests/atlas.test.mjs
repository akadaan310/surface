import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {equatorialToCartesian, projectStars, validateCatalogue} from '../dist/js/atlas.mjs';

const near=(a,b,t=1e-12)=>assert.ok(Math.abs(a-b)<t,`${a} != ${b}`);
test('ICRS cardinal basis uses degrees and preserves physical radius',()=>{
  for(const [ra,dec,r,want] of [[0,0,2,[2,0,0]],[90,0,3,[0,3,0]],[0,90,4,[0,0,4]],[180,0,1,[-1,0,0]]]){
    const got=equatorialToCartesian(ra,dec,r); ['x','y','z'].forEach((k,i)=>near(got[k],want[i]));
  }
  assert.throws(()=>equatorialToCartesian(0,91,1));
  assert.throws(()=>equatorialToCartesian(0,0,-1));
  assert.throws(()=>equatorialToCartesian('0',0));
});
test('orthographic camera has independently known center, north and horizon',()=>{
  const stars=[{id:'center',ra:0,dec:0,mag:1},{id:'east',ra:90,dec:0,mag:2},{id:'north',ra:0,dec:90,mag:3},{id:'back',ra:180,dec:0,mag:4}];
  const p=projectStars(stars,{width:800,height:600});
  assert.equal(p.length,3); const get=id=>p.find(s=>s.id===id);
  near(get('center').x,400);near(get('center').y,300);near(get('center').depth,1);
  near(get('east').x,700);near(get('north').y,0);
  const rotated=projectStars(stars,{width:800,height:600,yaw:Math.PI/2});
  near(rotated.find(s=>s.id==='east').x,400);
  assert.throws(()=>projectStars(stars,{width:0,height:600}));
});
test('catalogue preserves real source IDs, exact raw data digest, bounds and missing distances',async()=>{
  const cat=JSON.parse(await readFile(new URL('../dist/data/gaia-dr3-bright.json',import.meta.url)));
  assert.equal(validateCatalogue(cat),cat);
  assert.equal(cat.stars.length,10000);
  assert.equal(cat.meta.frame,'ICRS');assert.equal(cat.meta.epochJulianYear,2016);
  assert.equal(cat.stars[0].id,'1576683529448755328');
  near(cat.stars[0].ra,193.50817846782095);near(cat.stars[0].dec,55.959784778923755);
  assert.ok(cat.stars.every(s=>s.distancePc===null));
  assert.equal(new Set(cat.stars.map(s=>s.id)).size,cat.stars.length);
  const raw=await readFile(new URL('../dist/data/gaia-dr3-bright-source.csv',import.meta.url));
  assert.equal(createHash('sha256').update(raw).digest('hex'),cat.meta.source.sha256);
  assert.equal(raw.byteLength,cat.meta.source.bytes);
  const spoof=structuredClone(cat);spoof.stars[0].ra=NaN;assert.throws(()=>validateCatalogue(spoof));
});
