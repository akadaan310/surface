import test from 'node:test';
import assert from 'node:assert/strict';
import { fitResolution, normalizedPoint, sampleField, validateViewState, MODES } from '../dist/js/view.mjs';

test('render resolution respects pixel budget without changing aspect', () => {
  const result = fitResolution(4000, 2000, 3, 1000000);
  assert.ok(result.width * result.height <= 1000000);
  assert.ok(Math.abs(result.width / result.height - 2) < 0.01);
  assert.throws(() => fitResolution(NaN, 100, 1));
});
test('pointer normalization handles viewport offsets and clamps boundary input', () => {
  assert.deepEqual(normalizedPoint(150, 100, {left:50,top:50,width:200,height:100}), {x:.5,y:.5});
  assert.deepEqual(normalizedPoint(-5, 300, {left:0,top:0,width:100,height:100}), {x:0,y:1});
});
test('field sampler bilinearly interpolates and handles grid borders', () => {
  const f = new Float32Array([0,2,4,6]);
  assert.equal(sampleField(f, 2, 2, .5, .5),3);
  assert.equal(sampleField(f, 2, 2, 1, 1),6);
  assert.equal(sampleField(f, 2, 2, -3, 2),4);
});
test('restored view accepts only known modes and bounded finite camera state', () => {
  assert.equal(validateViewState({mode:'cosmos',zoom:2,yaw:1,pitch:0}).zoom,2);
  assert.throws(() => validateViewState({mode:'arbitrary',zoom:1}));
  assert.throws(() => validateViewState({mode:'coupled',zoom:Infinity}));
  assert.throws(() => validateViewState({mode:'cosmos',zoom:99}));
  assert.equal(MODES.length,7);
});
