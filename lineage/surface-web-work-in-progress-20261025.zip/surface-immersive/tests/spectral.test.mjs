import test from 'node:test';
import assert from 'node:assert/strict';
import { wavelengthToLinearRGB, faradayRotation, malusTransmission, zeemanShiftHz } from '../dist/js/spectral.mjs';

test('visible spectral samples preserve their dominant display primary',()=>{
  const blue=wavelengthToLinearRGB(450),green=wavelengthToLinearRGB(530),red=wavelengthToLinearRGB(650);
  assert.ok(blue[2]>blue[0] && blue[2]>blue[1]);
  assert.ok(green[1]>green[0] && green[1]>green[2]);
  assert.ok(red[0]>red[1] && red[0]>red[2]);
  for(let nm=360;nm<=830;nm++)assert.ok(wavelengthToLinearRGB(nm).every(v=>v>=0&&v<=1&&Number.isFinite(v)));
});
test('wavelength domain and malformed values are handled explicitly',()=>{
  assert.deepEqual(wavelengthToLinearRGB(100),[0,0,0]);
  assert.deepEqual(wavelengthToLinearRGB(900),[0,0,0]);
  assert.throws(()=>wavelengthToLinearRGB(NaN));
});
test('Faraday and Malus reference obey rotation sign and crossed-polarizer extinction',()=>{
  assert.equal(faradayRotation(40,.2,.125),1);
  assert.equal(faradayRotation(40,-.2,.125),-1);
  assert.equal(malusTransmission(0),1);
  assert.ok(malusTransmission(Math.PI/2)<1e-30);
  assert.ok(Math.abs(malusTransmission(Math.PI/4)-.5)<1e-14);
  assert.throws(()=>faradayRotation(1,1,-1));
});
test('weak-field Zeeman shift uses the Bohr-magneton frequency factor',()=>{
  assert.ok(Math.abs(zeemanShiftHz(1)-13.996244917e9)<10);
  assert.equal(zeemanShiftHz(0),0);
  assert.equal(zeemanShiftHz(-.1),-zeemanShiftHz(.1));
  assert.throws(()=>zeemanShiftHz(Infinity));
});
