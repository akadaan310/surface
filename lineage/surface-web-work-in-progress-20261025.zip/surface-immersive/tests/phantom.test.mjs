import test from 'node:test';
import assert from 'node:assert/strict';
import {admitDenseFinite,numericToEnvelope,envelopeToNumeric,wordTransition,encodePulseBits,decodePulseBits,simulateCircuit} from '../dist/js/phantom.mjs';

test('numeric admission rejects sparse, inherited, coercive and nonfinite entries',()=>{
  for(const x of [[1,,3],[1,NaN],[1,Infinity],[true,2],['1'],{0:1,length:1},new BigInt64Array([1n])])assert.throws(()=>admitDenseFinite(x));
  const inherited=Object.assign(Object.create([9]),{length:1});assert.throws(()=>admitDenseFinite(inherited));
  const getter=[1];Object.defineProperty(getter,'0',{get(){throw Error('must not evaluate getter');}});assert.throws(()=>admitDenseFinite(getter),/data|accessor/);
  assert.deepEqual([...admitDenseFinite(new Float32Array([1,2]))],[1,2]);
});
test('byte fixtures enforce endian, signed zero and source provenance',async()=>{
  const little=await numericToEnvelope([1,-2],{dtype:'i16',endianness:'little'});
  const big=await numericToEnvelope([1,-2],{dtype:'i16',endianness:'big'});
  assert.equal(little.bytesHex,'0100feff');assert.equal(big.bytesHex,'0001fffe');
  const exact=await numericToEnvelope([-0,1,Math.PI],{dtype:'f64'});
  assert.equal(exact.bytesHex.slice(0,16),'0000000000000080');
  const {values,sourceValues}=await envelopeToNumeric(exact);
  assert.ok(Object.is(values[0],-0));assert.equal(values[2],Math.PI);assert.equal(sourceValues[2],Math.PI);
  assert.equal(exact.lossPolicy.kind,'exact');
  const altered=structuredClone(exact);altered.bytesHex=altered.bytesHex.replace(/^00/,'01');await assert.rejects(envelopeToNumeric(altered),/digest|payload/);
  const endian=structuredClone(big);endian.endianness='little';await assert.rejects(envelopeToNumeric(endian),/digest|envelope/);
});
test('quantization is explicit, source is retained, integer overflow always rejects',async()=>{
  await assert.rejects(numericToEnvelope([1/3],{dtype:'f32'}),/loss|represent/);
  const e=await numericToEnvelope([1/3],{dtype:'f32',allowLoss:true});
  assert.equal(e.lossPolicy.kind,'quantized');assert.equal(e.lossPolicy.changedValues,1);
  const d=await envelopeToNumeric(e);assert.equal(d.values[0],Math.fround(1/3));assert.equal(d.sourceValues[0],1/3);
  for(const value of [256,-1,.5])await assert.rejects(numericToEnvelope([value],{dtype:'u8',allowLoss:true}));
});
test('PHANTOM inject carries while invert toggles and assignment stays distinct',()=>{
  const add=wordTransition(7n,{width:8,op:'INJECT',place:0});
  const toggle=wordTransition(7n,{width:8,op:'INVERT',place:0});
  assert.equal(add.after,'8');assert.equal(toggle.after,'6');
  assert.deepEqual(add.changedPlaces,[0,1,2,3]);assert.deepEqual(toggle.changedPlaces,[0]);
  assert.equal(add.trace[2].carryOut,1);assert.equal(add.trace[3].carryOut,0);
  assert.equal(wordTransition(255n,{width:8,op:'INJECT',place:0}).overflow,true);
  assert.equal(wordTransition(7n,{width:8,op:'ASSIGN',place:0,value:1}).after,'7');
  assert.throws(()=>wordTransition(256n,{width:8,op:'INVERT',place:0}));
});
test('presence and transition-toggle semantics carry their initial state and differ',()=>{
  const bits=[1,1,0,1,0,0];
  const p=encodePulseBits(bits,{mode:'presence'}),t=encodePulseBits(bits,{mode:'toggle',initial:0});
  assert.deepEqual(p.events,[1,1,0,1,0,0]);assert.deepEqual(t.events,[1,0,1,1,1,0]);
  assert.deepEqual(decodePulseBits(p),bits);assert.deepEqual(decodePulseBits(t),bits);
  assert.throws(()=>encodePulseBits([1,,0]));assert.throws(()=>encodePulseBits([true,0]));
});
test('bounded state-vector port reproduces Bell probabilities and phase-sensitive interference',()=>{
  const bell=simulateCircuit(2,[{gate:'H',target:0},{gate:'CX',control:0,target:1}]);
  const expected=[.5,0,0,.5];bell.probabilities.forEach((p,i)=>assert.ok(Math.abs(p-expected[i])<1e-12));
  const one=simulateCircuit(1,[{gate:'H',target:0},{gate:'Z',target:0},{gate:'H',target:0}]);
  assert.ok(one.probabilities[1]>1-1e-12);
  const rx=simulateCircuit(1,[{gate:'RX',target:0,theta:Math.PI}]);assert.ok(rx.probabilities[1]>1-1e-12);
  const yy=simulateCircuit(1,[{gate:'Y',target:0},{gate:'Y',target:0}]);assert.ok(yy.probabilities[0]>1-1e-12);
  assert.throws(()=>simulateCircuit(7,[]));assert.throws(()=>simulateCircuit(1,[{gate:'RX',target:0,theta:NaN}]));
  assert.throws(()=>simulateCircuit(2,[{gate:'CX',control:0,target:0}]));
});
