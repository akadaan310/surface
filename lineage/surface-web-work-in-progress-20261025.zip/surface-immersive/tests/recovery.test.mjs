import test from 'node:test';
import assert from 'node:assert/strict';

const bridgeModule = await import('../dist/js/simulation-bridge.mjs').catch(() => ({}));
const { SimulationBridge } = bridgeModule;

function snapshot(lastInputId = 0) {
  return { schema: 'surface-simulation', version: 1, engineVersion: 1, lastInputId, inputLog: [], engine: {
    schema: 'surface-physics', version: 1, width: 16, height: 16, seed: 1, rng: 1, time: 0,
    fields: { density: Array(256).fill(0), heat: Array(256).fill(0), pressure: Array(256).fill(0), velocity: Array(256).fill(0) },
    sources: [], nextSourceId: 0, circuit: {}, memory: {}, statistics: {}
  } };
}

class ManualClock {
  time = 0; nextId = 0; timers = new Map();
  now = () => this.time;
  setTimeout = (callback, delay) => { const id = ++this.nextId; this.timers.set(id, { callback, at: this.time + delay }); return id; };
  clearTimeout = id => this.timers.delete(id);
  setInterval = (callback, delay) => { const id = ++this.nextId; this.timers.set(id, { callback, at: this.time + delay, delay }); return id; };
  clearInterval = id => this.timers.delete(id);
  advance(ms) {
    const target = this.time + ms;
    for (;;) {
      const due = [...this.timers].filter(([, timer]) => timer.at <= target).sort((a, b) => a[1].at - b[1].at)[0];
      if (!due) break;
      const [id, timer] = due; this.time = timer.at;
      if (timer.delay) timer.at += timer.delay; else this.timers.delete(id);
      timer.callback();
    }
    this.time = target;
  }
}

class FakeWorker {
  sent = []; terminated = false; onmessage = null; onerror = null; onmessageerror = null;
  postMessage(message) { this.sent.push(structuredClone(message)); }
  terminate() { this.terminated = true; }
  emit(message) { this.onmessage?.({ data: message }); }
  reply(request, result) { this.emit({ type: 'response', epoch: request.epoch, requestId: request.requestId, ok: true, result }); }
}

function harness(extraOptions = {}) {
  assert.equal(typeof SimulationBridge, 'function', 'worker bridge is implemented');
  const clock = new ManualClock(); const workers = []; const frames = []; const statuses = []; const checkpoints = [];
  const visibility = { hidden: false, addEventListener(_name, callback) { this.listener = callback; }, removeEventListener() {} };
  const bridge = new SimulationBridge({ onFrame: frame => frames.push(frame), onStatus: status => statuses.push(status), onCheckpoint: state => checkpoints.push(state), options: {
    workerFactory: () => { const worker = new FakeWorker(); workers.push(worker); return worker; },
    clock, visibility, checkpointIntervalMs: 30000, engine: { width: 16, height: 16, seed: 1 }, ...extraOptions
  } });
  return { bridge, clock, workers, frames, statuses, checkpoints, visibility };
}

async function initialize(h, state = snapshot()) {
  const starting = h.bridge.start(state); const worker = h.workers.at(-1);
  worker.reply(worker.sent.find(message => message.type === 'init'), { snapshot: state });
  await starting;
  return worker;
}

test('a visible stalled worker is terminated and restores the last full state', async () => {
  const h = harness(); const initial = snapshot(); initial.engine.time = 12;
  const oldWorker = await initialize(h, initial);
  h.clock.advance(6500);
  assert.equal(oldWorker.terminated, true);
  assert.equal(h.statuses.at(-1).state, 'RECOVERING');
  assert.equal(h.workers.length, 2);
  const init = h.workers[1].sent.find(message => message.type === 'init');
  assert.equal(init.snapshot.engine.time, 12);
  h.bridge.dispose();
});

test('late frames and replies from a retired epoch cannot overwrite the recovered state', async () => {
  const h = harness(); const old = await initialize(h);
  const staleEpoch = old.sent[0].epoch;
  h.clock.advance(6500);
  const current = h.workers.at(-1); const init = current.sent.find(message => message.type === 'init');
  current.reply(init, { snapshot: snapshot() });
  await Promise.resolve(); await Promise.resolve();
  old.emit({ type: 'frame', epoch: staleEpoch, frame: { marker: 'stale' } });
  current.emit({ type: 'frame', epoch: staleEpoch, frame: { marker: 'forged-epoch' } });
  current.emit({ type: 'frame', epoch: init.epoch, frame: { marker: 'current' } });
  assert.deepEqual(h.frames.map(frame => frame.marker), ['current']);
  assert.equal(h.statuses.at(-1).state, 'RUNNING');
  h.bridge.dispose();
});

test('a pending request rejects within four seconds and triggers bounded recovery', async () => {
  const h = harness(); await initialize(h);
  const request = h.bridge.checkpoint();
  const rejected = assert.rejects(request, /timeout|deadline/i);
  h.clock.advance(4000);
  await rejected;
  assert.equal(h.workers.length, 2);
  h.bridge.dispose();
});

test('the third failure within a minute pauses instead of creating an endless restart loop', async () => {
  const h = harness(); await initialize(h);
  for (let attempt = 0; attempt < 3; attempt++) {
    h.workers.at(-1).onerror?.({ message: 'worker failed', preventDefault() {} });
    if (attempt < 2) {
      const worker = h.workers.at(-1);
      worker.reply(worker.sent.find(message => message.type === 'init'), { snapshot: snapshot() });
      await Promise.resolve(); await Promise.resolve();
    }
  }
  assert.equal(h.workers.length, 3);
  assert.equal(h.statuses.at(-1).state, 'PAUSED');
  h.clock.advance(60000);
  assert.equal(h.workers.length, 3);
  h.bridge.dispose();
});

test('hidden tabs do not consume the failure budget and receive a fresh visible grace period', async () => {
  const h = harness(); const worker = await initialize(h);
  h.visibility.hidden = true; h.visibility.listener(); h.clock.advance(120000);
  assert.equal(h.workers.length, 1);
  assert.equal(worker.terminated, false);
  h.visibility.hidden = false; h.visibility.listener(); h.clock.advance(5500);
  assert.equal(h.workers.length, 1);
  h.clock.advance(1000);
  assert.equal(h.workers.length, 2);
  h.bridge.dispose();
});

test('inputs since the last full checkpoint replay once after recovery', async () => {
  const h = harness(); const worker = await initialize(h);
  h.bridge.inject({ x: 0.4, y: 0.6, dx: 0, dy: 0, strength: 1, radius: 0.03, mode: 'ink' });
  const input = worker.sent.find(message => message.type === 'inject');
  worker.emit({ type: 'ack', epoch: input.epoch, inputId: input.inputId });
  h.clock.advance(6500);
  const next = h.workers.at(-1); const init = next.sent.find(message => message.type === 'init');
  next.reply(init, { snapshot: snapshot() }); await Promise.resolve(); await Promise.resolve();
  const replay = next.sent.filter(message => message.type === 'inject');
  assert.equal(replay.length, 1);
  assert.equal(replay[0].inputId, input.inputId);
  assert.deepEqual(replay[0].event, input.event);
  h.bridge.dispose();
});
