import test from 'node:test';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';

const checkpointModule = await import('../dist/js/checkpoints.mjs').catch(() => ({}));
const { createCheckpointStore, exportCheckpoint, validateCheckpoint } = checkpointModule;

function snapshot() {
  return {
    schema: 'surface-simulation', version: 1, engineVersion: 1, lastInputId: 0, inputLog: [],
    engine: {
      schema: 'surface-physics', version: 1, width: 16, height: 16, seed: 7, rng: 7, time: 0,
      fields: { density: Array(256).fill(0), heat: Array(256).fill(0), pressure: Array(256).fill(0), velocity: Array(256).fill(0) },
      sources: [], nextSourceId: 0,
      circuit: { i1: 0, i2: 0, q1: 0, q2: 0, soc: 0, batteryEnergy: 0, drivePhase: 0, harvestedEnergy: 0, dissipatedEnergy: 0, drive: 0 },
      memory: { relays: [], magnetization: 0, appliedField: 0 },
      statistics: { steps: 0, discardedTime: 0, injections: 0 }
    }
  };
}

function memoryStorage() {
  const data = new Map();
  return { data, getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, String(value)), removeItem: key => data.delete(key) };
}

test('portable checkpoints preserve full numeric state and signed metadata', async () => {
  assert.equal(typeof exportCheckpoint, 'function', 'checkpoint export is implemented');
  const state = snapshot();
  state.engine.fields.density[17] = 0.125;
  const envelope = await exportCheckpoint(state, { mode: 'heat', paused: false });
  const verified = await validateCheckpoint(JSON.stringify(envelope));
  assert.equal(verified.snapshot.engine.fields.density[17], 0.125);
  assert.deepEqual(verified.metadata, { mode: 'heat', paused: false });
  assert.match(envelope.digest, /^[a-f0-9]{64}$/);
});

test('a changed body, schema, timestamp, or digest cannot be admitted', async () => {
  assert.equal(typeof exportCheckpoint, 'function');
  const original = await exportCheckpoint(snapshot(), { mode: 'wave' });
  for (const changed of [
    { ...original, body: original.body.replace('wave', 'heat') },
    { ...original, schema: 'another-format' },
    { ...original, savedAt: '2020-01-01T00:00:00.000Z' },
    { ...original, digest: '0'.repeat(64) }
  ]) await assert.rejects(() => validateCheckpoint(changed), /integrity|schema|digest/i);
});

test('sparse, nonfinite, wrongly sized, and oversized input are rejected before serialization', async () => {
  assert.equal(typeof exportCheckpoint, 'function');
  const sparse = snapshot(); delete sparse.engine.fields.heat[8];
  const infinite = snapshot(); infinite.engine.fields.pressure[0] = Infinity;
  const wrongSize = snapshot(); wrongSize.engine.fields.velocity.pop();
  const wrongVersion = snapshot(); wrongVersion.engineVersion = 2;
  for (const state of [sparse, infinite, wrongSize, wrongVersion]) {
    await assert.rejects(() => exportCheckpoint(state), /sparse|finite|length|version/i);
  }
  await assert.rejects(() => exportCheckpoint(snapshot(), { padding: 'x'.repeat(11 * 1024 * 1024) }), /size|large|limit/i);
});

test('fallback saves retain the previous good slot when the latest bytes are corrupt', async () => {
  assert.equal(typeof createCheckpointStore, 'function');
  const storage = memoryStorage();
  let time = Date.UTC(2026, 0, 1);
  const store = createCheckpointStore({ indexedDB: null, localStorage: storage, crypto: webcrypto, now: () => time++ });
  const a = snapshot(); a.engine.time = 1;
  await store.saveCheckpoint(a, { mode: 'ink' });
  const b = snapshot(); b.engine.time = 2;
  const second = await store.saveCheckpoint(b, { mode: 'heat' });
  assert.equal(second.storage, 'localStorage');
  for (const [key, value] of storage.data) {
    if (value.includes(second.digest)) storage.data.set(key, value.replace(second.digest, 'f'.repeat(64)));
  }
  const restored = await store.validateCheckpoint(await store.loadCheckpoint());
  assert.equal(restored.snapshot.engine.time, 1);
  const c = snapshot(); c.engine.time = 3;
  await store.saveCheckpoint(c);
  const newest = await store.validateCheckpoint(await store.loadCheckpoint());
  assert.equal(newest.snapshot.engine.time, 3);
});

test('storage quota errors reject while leaving a committed checkpoint readable', async () => {
  assert.equal(typeof createCheckpointStore, 'function');
  const storage = memoryStorage();
  const store = createCheckpointStore({ indexedDB: null, localStorage: storage, crypto: webcrypto });
  const first = await store.saveCheckpoint(snapshot());
  storage.setItem = () => { throw new Error('QuotaExceededError'); };
  await assert.rejects(() => store.saveCheckpoint(snapshot()), /storage|quota|save/i);
  assert.equal((await store.loadCheckpoint()).digest, first.digest);
});

test('invalid imports cannot replace a valid committed state', async () => {
  assert.equal(typeof createCheckpointStore, 'function');
  const storage = memoryStorage();
  const store = createCheckpointStore({ indexedDB: null, localStorage: storage, crypto: webcrypto });
  const good = await store.saveCheckpoint(snapshot(), { mode: 'ink' });
  await assert.rejects(() => store.importCheckpoint({ ...good, body: '{}' }));
  assert.equal((await store.loadCheckpoint()).digest, good.digest);
});
